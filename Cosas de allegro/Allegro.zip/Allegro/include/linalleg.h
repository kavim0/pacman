/*         ______   ___    ___
 *        /\  _  \ /\_ \  /\_ \
 *        \ \ \L\ \\//\ \ \//\ \      __     __   _ __   ___
 *         \ \  __ \ \ \ \  \ \ \   /'__`\ /'_ `\/\`'__\/ __`\
 *          \ \ \/\ \ \_\ \_ \_\ \_/\  __//\ \L\ \ \ \//\ \L\ \
 *           \ \_\ \_\/\____\/\____\ \____\ \____ \ \_\\ \____/
 *            \/_/\/_/\/____/\/____/\/____/\/___L\ \/_/ \/___/
 *                                           /\____/
 *                                           \_/__/
 *
 *      Linux header file for the Allegro library.
 *
 *      This file no longer contains anything.  At the moment,
 *      it exists only for backwards compatibility.
 *
 *      See readme.txt for copyright information.
 */


#ifndef LIN_ALLEGRO_H
#define LIN_ALLEGRO_H

/*
 * THIS IS AN EX-PARROT!!
 */

#endif          /* ifndef LIN_ALLEGRO_H */


